import { Modal, Form, Input, Select, DatePicker } from "antd";

const EmployeeForm = ({
  open,
  onCancel,
  onSubmit,
  initialValues,
}) => {
  const [form] = Form.useForm();

  return (
    <Modal
      open={open}
      onCancel={onCancel}
      onOk={() => form.submit()}
      title={
        initialValues ? "Edit Employee" : "Add Employee"
      }
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={initialValues}
        onFinish={onSubmit}
      >
        <Form.Item
          name="name"
          label="Name"
          rules={[{ required: true }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          name="email"
          label="Email"
          rules={[{ required: true }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          name="department"
          label="Department"
        >
          <Select
            options={[
              { label: "HR", value: "HR" },
              { label: "IT", value: "IT" },
              { label: "Finance", value: "Finance" },
            ]}
          />
        </Form.Item>

        <Form.Item
          name="designation"
          label="Designation"
        >
          <Input />
        </Form.Item>

        <Form.Item
          name="status"
          label="Status"
        >
          <Select
            options={[
              { label: "Active", value: "Active" },
              { label: "Inactive", value: "Inactive" },
            ]}
          />
        </Form.Item>

        <Form.Item
          name="joiningDate"
          label="Joining Date"
        >
          <DatePicker style={{ width: "100%" }} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EmployeeForm;