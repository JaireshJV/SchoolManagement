import { Form, Input, Button, Card, message } from "antd";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const Login = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (values) => {
    try {
      const res = await api.post("/auth/login", values);

      login(res.data.token);

      message.success("Login Success");

      navigate("/dashboard");
    } catch {
      message.error("Invalid Credentials");
    }
  };

  return (
    <div
      style={{
        height: "100vh",
        display: "grid",
        placeItems: "center",
      }}
    >
      <Card title="Login" style={{ width: 400 }}>
        <Form onFinish={handleSubmit}>
          <Form.Item
            name="email"
            rules={[
              { required: true },
              { type: "email" },
            ]}
          >
            <Input placeholder="Email" />
          </Form.Item>

          <Form.Item
            name="password"
            rules={[{ required: true }]}
          >
            <Input.Password placeholder="Password" />
          </Form.Item>

          <Button
            htmlType="submit"
            type="primary"
            block
          >
            Login
          </Button>
        </Form>
      </Card>
    </div>
  );
};

export default Login;