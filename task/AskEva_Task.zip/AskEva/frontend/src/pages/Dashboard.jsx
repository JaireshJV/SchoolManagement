import {
  Button,
  Input,
  Select,
  Space,
} from "antd";
import { useEffect, useState } from "react";
import api from "../api/axios";

import EmployeeTable from "../components/EmployeeTable";
import EmployeeForm from "./EmployeeForm";
import AnalyticsCards from "../components/AnalyticsCards";
import AnalyticsChart from "../components/AnalyticsChart";

const Dashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [filtered, setFiltered] = useState([]);

  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);

  const [search, setSearch] = useState("");

  const fetchEmployees = async () => {
    const res = await api.get("/employees");

    setEmployees(res.data);
    setFiltered(res.data);
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  useEffect(() => {
    let data = [...employees];

    if (search) {
      data = data.filter(
        (e) =>
          e.name
            .toLowerCase()
            .includes(search.toLowerCase()) ||
          e.email
            .toLowerCase()
            .includes(search.toLowerCase())
      );
    }

    setFiltered(data);
  }, [search, employees]);

  const createEmployee = async (values) => {
    await api.post("/employees", values);

    setOpen(false);

    fetchEmployees();
  };

  const updateEmployee = async (values) => {
    await api.put(
      `/employees/${selected.id}`,
      values
    );

    setOpen(false);

    fetchEmployees();
  };

  const deleteEmployee = async (id) => {
    await api.delete(`/employees/${id}`);

    fetchEmployees();
  };

  return (
    <div style={{ padding: 20 }}>
      <AnalyticsCards employees={employees} />

      <AnalyticsChart employees={employees} />

      <Space
        style={{
          marginTop: 20,
          marginBottom: 20,
        }}
      >
        <Input
          placeholder="Search"
          onChange={(e) =>
            setSearch(e.target.value)
          }
        />

        <Button
          type="primary"
          onClick={() => {
            setSelected(null);
            setOpen(true);
          }}
        >
          Add Employee
        </Button>
      </Space>

      <EmployeeTable
        data={filtered}
        onEdit={(row) => {
          setSelected(row);
          setOpen(true);
        }}
        onDelete={deleteEmployee}
      />

      <EmployeeForm
        open={open}
        initialValues={selected}
        onCancel={() => setOpen(false)}
        onSubmit={
          selected
            ? updateEmployee
            : createEmployee
        }
      />
    </div>
  );
};

export default Dashboard;