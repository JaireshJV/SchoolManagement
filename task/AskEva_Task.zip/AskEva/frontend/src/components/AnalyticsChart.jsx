
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from "recharts";

const AnalyticsChart = ({ employees }) => {
  const active = employees.filter(
    (e) => e.status === "Active"
  ).length;

  const inactive = employees.length - active;

  const data = [
    {
      name: "Active",
      value: active,
    },
    {
      name: "Inactive",
      value: inactive,
    },
  ];

  return (
    <PieChart width={400} height={300}>
      <Pie
        data={data}
        dataKey="value"
        outerRadius={100}
        label
      >
        <Cell fill="#52c41a" />
        <Cell fill="#ff4d4f" />
      </Pie>

      <Tooltip />
    </PieChart>
  );
};

export default AnalyticsChart;