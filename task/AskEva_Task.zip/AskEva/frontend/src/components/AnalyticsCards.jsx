import { Card, Col, Row } from "antd";

const AnalyticsCards = ({ employees }) => {
  const total = employees.length;

  const active = employees.filter(
    (emp) => emp.status === "Active"
  ).length;

  return (
    <Row gutter={16}>
      <Col span={12}>
        <Card title="Total Employees">
          {total}
        </Card>
      </Col>

      <Col span={12}>
        <Card title="Active Employees">
          {active}
        </Card>
      </Col>
    </Row>
  );
};

export default AnalyticsCards;