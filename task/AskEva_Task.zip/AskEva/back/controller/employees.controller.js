import { createEmployee, deleteEmployee, getAllEmployees, getEmployeeById, updateEmployee } from "../services/employee.service.js";

export const getEmployees = async (req, res) =>{
    try{

        const { search, department, status, page, limit } =req.query;

        const employees = await getAllEmployees({
            search, department, status, page, limit
        });

        console.log(employees, "Retrived Employees");

        if(!employees){
            return res.status(404).json({
                success: false,
                message: "❌ No Employees data found"
            })
        }

        return res.status(200).json({
            success: true,
            message: "✅ Employees fetched successfully",
            data: employees
        })
    }catch(error){
        console.error("❌ Fetching Employees Failed", error.message);
        res.status(500).json({
            success: false,
            message: error.message,
            stack: error.stack
        })
    }
}

export const getEmployeesById = async (req, res) =>{
    try{
        const { id } = req.params;

        if(!id){
            return res.status(400).json({
                success: false,
                message: "❌ Missing required fields"
            })
        }

        console.log(id, "Recived Id");

        const employees = await getEmployeeById(id);

        if(!employees){
            return res.status(400).json({
                success: false,
                message: "❌ No Employee data found"
            })
        }

        return res.status(200).json({
            success: true,
            message: "✅ Employee Details fetched successfully",
            data: employees
        })
    }catch(error){
        console.error("❌ Fetching Employee Details Failed", error.message);
        res.status(500).json({
            success: false,
            message: error.message,
            stack: error.stack
        })
    }
}

export const addEmployee = async (req, res) => {
  try {
    const employee = await createEmployee(req.body);

    return res.status(201).json({
      success: true,
      message: "✅ Employee created successfully",
      data: employee,
    });
  } catch (error) {
    console.error("❌ Create Employees Failed", error.message);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const editEmployee = async (req, res) =>{
    try{
        const { id } = req.params;
        const payload = req.body;

        const existing = await getEmployeeById(id);

        if(!existing){
            return res.status(404).json({
                success: false,
                message: "❌ No Employee data found to update"
            })
        }

        const employees = await updateEmployee(id, payload);

        return res.status(200).json({
            success: true,
            message: "✅ Employee updated successfully",
            data: employees
        })
    }catch(error){
        console.error("❌ Updating Employee Failed", error.message);
        res.status(500).json({
            success: false,
            message: error.message,
            stack: error.stack
        })
    }
}

export const removeEmployee = async (req, res) => {
  try {
    const { id } = req.params;

    const employee = await deleteEmployee(id);

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "❌ Employee not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "✅ Employee deleted successfully",
    });
  } catch (error) {
    console.error("❌ Employee Delete Failed", error.message);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};