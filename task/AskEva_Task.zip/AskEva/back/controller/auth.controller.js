import { loginUser } from "../services/auth.service.js";
import bcrypt from "bcryptjs";


export const login = async (req, res) => {
  try {

//   const hash = await bcrypt.hash("admin123", 10);
//   console.log(hash, "Hashed Password");

    const { email, password } = req.body;

    const result = await loginUser(email, password);

    return res.status(200).json({
      success: true,
      message: "✅ Login successful",
      data: result,
    });
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: error.message,
    });
  }
};