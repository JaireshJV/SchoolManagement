import express from "express";
import employeesRoutes from './employees.routes.js';
import authRoutes from './auth.routes.js';

const router = express.Router();

router.use('/employees', employeesRoutes);
router.use('/auth', authRoutes);


export default router;