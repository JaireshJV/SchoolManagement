import express from "express";
import { addEmployee, editEmployee, getEmployees, getEmployeesById, removeEmployee } from "../controller/employees.controller.js";
import { verifyToken } from "../utils/jwt.js";
import { authenticate } from "../middleware/aut.middleware.js";

const router = express.Router();

router.get('/', authenticate, getEmployees);
router.post('/', authenticate, addEmployee);
router.get('/:id', authenticate, getEmployeesById);
router.put('/:id', authenticate, editEmployee);
router.delete('/:id', authenticate, removeEmployee);


export default router;
