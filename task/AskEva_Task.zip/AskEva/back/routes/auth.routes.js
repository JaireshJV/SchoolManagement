import express from "express";
import { login } from "../controller/auth.controller.js";
import { verifyToken } from "../utils/jwt.js";

const router = express.Router();

router.post("/login", login);

export default router;