import express from 'express';
import cors from 'cors';
import indexRoutes from './routes/index.routes.js';
import dotenv from 'dotenv/config.js';
import { getConnection } from './config/db.js';

// Create Server
const server = async () => {
  try {

    // Create Express App
    const app = express();

    // Basic Middlewares
    app.use(express.json());

    // CORS
    app.use(cors({
      origin: "*",
    }));

    // app.use(cors({
    // origin: process.env.CLIENT_URL || "http://localhost:3000",
    // credentials: true
    // }));

    // Database Connection
    await getConnection();

    //PORT
    const PORT = process.env.PORT || "5000";

    if(!PORT){
        console.error("PORT is missing");
    }

    // Base API Route
    const BASE_URL = `${process.env.BASE_API || 'http://localhost:5000' }`;

    if(!BASE_URL){
        console.error("Base Api is not found");
    }

    // API Routes
    app.use('/api', indexRoutes);

    // Start Server
    app.listen(PORT, () => {

      console.log(
        `🚀 Server running on ${BASE_URL}: ${PORT}`
      );

    });

  } catch (error) {
    console.error('❌ Server startup failed', error.message);
    process.exit(1);
  }

};

// Run Server
server();