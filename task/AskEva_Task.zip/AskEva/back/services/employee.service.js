import Employee from "../models/employee.model.js";

export const getAllEmployees = async (filters) => {
  const page = Number(filters.page) || 1;
  const limit = Number(filters.limit) || 10;
  const skip = (page - 1) * limit;

  const query = {};

  if (filters.search) {
    query.$or = [
      { name: { $regex: filters.search, $options: "i" } },
      { email: { $regex: filters.search, $options: "i" } },
    ];
  }

  if (filters.department) {
    query.department = filters.department;
  }

  if (filters.status) {
    query.status = filters.status;
  }

  const [employees, total] = await Promise.all([
    Employee.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
    Employee.countDocuments(query),
  ]);

  return {
    employees,
    pagination: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    },
  };
};

export const getEmployeeById = async (id) => {
  return await Employee.findById(id);
};

export const createEmployee = async (payload) => {
  return await Employee.create(payload);
};

export const updateEmployee = async (id, payload) => {
  return await Employee.findByIdAndUpdate(id, payload, {
    new: true,
    runValidators: true,
  });
};

export const deleteEmployee = async (id) => {
  return await Employee.findByIdAndDelete(id);
};
