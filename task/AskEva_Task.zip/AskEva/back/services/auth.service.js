import bcrypt from "bcryptjs";
import User from "../models/user.models.js";
import { generateToken } from "../utils/jwt.js";

export const loginUser = async (email, password) => {
  
    const user = await User.findOne({ email });

    console.log(user, "Retrived users");

  if (!user) {
    throw new Error("Invalid email or password");
  }

  const isPasswordValid = await bcrypt.compare(
    password,
    user.password
  );

  if (!isPasswordValid) {
    throw new Error("Invalid email or password");
  }

  const token = generateToken({
    id: user._id,
    email: user.email,
    role: user.role,
  });

  return {
    token,
    user: {
      id: user._id,
      email: user.email,
      role: user.role,
    },
  };
};