import mongoose from "mongoose";

const employeeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    department: {
      type: String,
    },
    designation: {
      type: String,
    },

    status: {
      type: String, 
      enum: ['Active', 'Inactive'],
      default: 'Active',
    },
    joinedDate: {
      type: String,
    },
  },
  {
    timestamps: true,
  },
);

const Employee = mongoose.model("Employee", employeeSchema.index({name: "text", email: "text"}));

export default Employee;

